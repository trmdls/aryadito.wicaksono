# Portfolio — GitHub Pages

This is the static HTML/CSS/JavaScript version of the portfolio.

## Files
- `index.html` — main portfolio page
- `style.css` — styling and responsive layout
- `script.js` — mobile menu, scroll reveal, active navigation, HIMSISFO accordion, and ISASC modal
- `assets/` — portfolio images

## Deploy to GitHub Pages
1. Create a GitHub repository.
2. Upload all files/folders from this directory to the repository root.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then save.
6. Open the generated GitHub Pages URL.

No npm, Node.js, React, TypeScript, or Vite is required.
